[![Board Status](https://dev.azure.com/ravikaanthe/e3e4b414-0437-4eff-909d-f13e4f118856/0afca5ad-eeb8-4739-a1d9-850d45ec58dc/_apis/work/boardbadge/ab7ab7af-811f-4093-aac2-5038d0817aa9)](https://dev.azure.com/ravikaanthe/e3e4b414-0437-4eff-909d-f13e4f118856/_boards/board/t/0afca5ad-eeb8-4739-a1d9-850d45ec58dc/Microsoft.RequirementCategory)

Sample Java SpringBoot web app used to demo CI/CD using Azure DevOps and deploying to Azure App Services. To check Azure Pull Requests and see if azure has this file. To check Git morror functionality

[![Build status](https://houssemdellai.visualstudio.com/Java-SpringBoot-WebApp/_apis/build/status/Java-SpringBoot-Maven-CI)](https://houssemdellai.visualstudio.com/Java-SpringBoot-WebApp/_build/latest?definitionId=96)

CI/CD pipelines on Azure DevOps:
https://houssemdellai.visualstudio.com/Java-SpringBoot-WebApp

